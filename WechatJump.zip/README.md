# 微信跳一跳

 ![Me](https://img.shields.io/badge/author-chaoszh-15b6e8?style=flat-square)
 [![GitHub license](https://img.shields.io/github/license/File-New-Project/EarTrumpet?style=flat-square)]()
 ![Maintenance status](https://img.shields.io/maintenance/yes/2020?style=flat-square)

## 🎦Preview
![](readme/preview.png)

## 🍊Features

* 复现微信跳一跳基础功能
* 加入灯光营造伪2D效果
* 加入cube模型
* 加入补间动画完善动作
* 加入音效管理

## 👩‍💻My links
[![GITHUB](http://img.shields.io/badge/caocao's%20space-github?&style=social&logo=Bitrise)](http://www.caocao.space)
[![GITHUB](http://img.shields.io/badge/chaoszh-github?&style=social&logo=Github)](https://github.com/ChaosZh)