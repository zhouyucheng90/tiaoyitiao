//游戏设置
import { init } from './game/index.js'
init()